﻿using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Automation;

namespace SaiBridge.Automation;

public static class SaiAutomation
{
    //==================================================
    // Win32
    //==================================================

    [DllImport("user32.dll")]
    private static extern bool SetForegroundWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();

    public static IntPtr FindForegroundWindow()
    {
        return GetForegroundWindow();
    }


    [DllImport("user32.dll")]
    private static extern bool ShowWindow(
        IntPtr hWnd,
        int nCmdShow);


    [DllImport("user32.dll")]
    private static extern bool IsIconic(
        IntPtr hWnd);


    [DllImport("user32.dll")]
    private static extern bool EnumWindows(
        EnumWindowsProc lpEnumFunc,
        IntPtr lParam);


    [DllImport("user32.dll")]
    private static extern int GetWindowText(
        IntPtr hWnd,
        StringBuilder text,
        int maxLength);


    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(
        IntPtr hWnd,
        out uint processId);



    private delegate bool EnumWindowsProc(
        IntPtr hWnd,
        IntPtr lParam);



    [DllImport("user32.dll")]
    private static extern void keybd_event(
        byte bVk,
        byte bScan,
        uint dwFlags,
        UIntPtr dwExtraInfo);



    private const int SW_RESTORE = 9;

    private const uint KEYEVENTF_KEYUP = 0x0002;



    // 键值

    private const byte VK_CONTROL = 0x11;
    private const byte VK_SHIFT = 0x10;

    private const byte VK_S = 0x53;
    private const byte VK_L = 0x4C;
    private const byte VK_V = 0x56;
    private const byte VK_A = 0x41;

    public static void PressCtrlA()
    {
        KeyDown(VK_CONTROL);
        KeyPress(VK_A);
        KeyUp(VK_CONTROL);
    }

    private const byte VK_RETURN = 0x0D;
    private const byte VK_ESCAPE = 0x1B;
    private const byte VK_TAB = 0x09;

    private const byte VK_UP = 0x26;
    private const byte VK_DOWN = 0x28;
    private const byte VK_LEFT = 0x25;
    private const byte VK_RIGHT = 0x27;

    private const byte VK_F5 = 0x74;
    private const byte VK_END = 0x23;



    //==================================================
    // 查找 SAI
    //==================================================


    public static Process? FindSaiProcess(string exePath)
    {
        if (!File.Exists(exePath))
            return null;


        string name =
            Path.GetFileNameWithoutExtension(exePath);


        foreach (Process p in Process.GetProcessesByName(name))
        {
            if (!p.HasExited)
                return p;
        }


        return null;
    }




    //==================================================
    // 激活 SAI
    //==================================================


    public static void Activate(Process process)
    {
        IntPtr hwnd = process.MainWindowHandle;


        if (hwnd == IntPtr.Zero)
            return;


        if (IsIconic(hwnd))
        {
            ShowWindow(hwnd, SW_RESTORE);
        }


        ShowWindow(hwnd, SW_RESTORE);


        Thread.Sleep(20);

        SetForegroundWindow(hwnd);

        Thread.Sleep(40);
    }





    //==================================================
    // 快捷键
    //==================================================


    public static void PressCtrlS()
    {
        KeyDown(VK_CONTROL);
        KeyPress(VK_S);
        KeyUp(VK_CONTROL);
    }



    public static void PressCtrlShiftS()
    {
        KeyDown(VK_CONTROL);
        KeyDown(VK_SHIFT);

        KeyPress(VK_S);

        KeyUp(VK_SHIFT);
        KeyUp(VK_CONTROL);
    }
    public static void PressCtrlO()
    {
        KeyDown(VK_CONTROL);
        KeyPress(0x4F);      // O
        KeyUp(VK_CONTROL);
    }

    public static void ExportPsd()
    {
        // Alt+F
        KeyDown(0x12);
        KeyPress(0x46);
        KeyUp(0x12);

        Thread.Sleep(80);

        KeyPress(0x45);

        Thread.Sleep(120);

        PressDown();

        Thread.Sleep(60);

        PressEnter();

        Thread.Sleep(250);
    }


    public static void PressCtrlL()
    {
        KeyDown(VK_CONTROL);
        KeyPress(VK_L);
        KeyUp(VK_CONTROL);
    }





    public static void PressCtrlV()
    {
        KeyDown(VK_CONTROL);
        KeyPress(VK_V);
        KeyUp(VK_CONTROL);
    }



    public static void PressEnter()
    {
        KeyPress(VK_RETURN);
    }



    public static void PressEsc()
    {
        KeyPress(VK_ESCAPE);
    }



    public static void PressTab()
    {
        KeyPress(VK_TAB);
    }



    public static void PressUp()
    {
        KeyPress(VK_UP);
    }


    public static void PressDown()
    {
        KeyPress(VK_DOWN);
    }


    public static void PressLeft()
    {
        KeyPress(VK_LEFT);
    }


    public static void PressRight()
    {
        KeyPress(VK_RIGHT);
    }



    public static void PressF5()
    {
        KeyPress(VK_F5);
    }

    public static void OpenPsdByMouse(
    IntPtr dialog,
    string psdPath)
    {
        var rect =
            MouseHelper.GetRect(dialog);


        string fileName =
            Path.GetFileName(psdPath);


        // 当前窗口里面缩略图区域
        // 根据你的截图调整

        int index = GetPsdIndex(dialog, psdPath);

        if (index < 0)
        {
            return;
        }


        // 每个缩略图宽度大约110
        int x =
            rect.Left + 80 + index * 120;


        int y =
            rect.Top + 300;


        MouseHelper.DoubleClick(
            x,
            y);


        MouseHelper.DoubleClick(
            x,
            y);


        Thread.Sleep(1500);
    }
    public static void PressEnd()
    {
        KeyPress(VK_END);
    }




    public static void Wait(int ms)
    {
        Thread.Sleep(ms);
    }




    //==================================================
    // 查找 SAI 保存窗口
    //==================================================


    public static IntPtr FindSaveDialog(Process sai)
    {
        IntPtr result = IntPtr.Zero;



        EnumWindows(
            (hWnd, lParam) =>
            {

                GetWindowThreadProcessId(
                    hWnd,
                    out uint pid);



                // 只检查 SAI 自己的窗口

                if (pid != sai.Id)
                    return true;



                StringBuilder sb =
                    new StringBuilder(256);



                GetWindowText(
                    hWnd,
                    sb,
                    sb.Capacity);



                string title =
                    sb.ToString();


                if (SaiCompatibility.Match(
        title,
        SaiCompatibility.SaveDialogs))
                {
                    result = hWnd;
                    return false;
                }

                return true;






            },
            IntPtr.Zero);



        return result;
    }




    //==================================================
    // 键盘底层
    //==================================================


    private static void KeyDown(byte key)
    {
        keybd_event(
            key,
            0,
            0,
            UIntPtr.Zero);
    }



    private static void KeyUp(byte key)
    {
        keybd_event(
            key,
            0,
            KEYEVENTF_KEYUP,
            UIntPtr.Zero);
    }



    private static void KeyPress(byte key)
    {
        KeyDown(key);

        Thread.Sleep(40);

        KeyUp(key);

        Thread.Sleep(40);
    }








    public static void TestAutomationPath(IntPtr hwnd)
    {
        AutomationElement root =
            AutomationElement.FromHandle(hwnd);


        AutomationElement? path =
            root.FindFirst(
                TreeScope.Descendants,
                new PropertyCondition(
                    AutomationElement.NameProperty,
                    "路径"));


        if (path == null)
        {
            Console.WriteLine("没有找到路径节点");
            return;
        }


        Console.WriteLine("找到路径节点");

        Console.WriteLine(
            path.Current.ControlType.ProgrammaticName);
    }
    public static void SetFileName(string text)
    {
        Thread.Sleep(500);

        PressCtrlA();

        Thread.Sleep(100);

        Clipboard.SetText(text);

        PressCtrlV();

        Thread.Sleep(500);
    }




    public static void SetPath(
     IntPtr dialog,
     string path)
    {
        var rect =
            MouseHelper.GetRect(dialog);


        int x =
            rect.Left + 500;


        int y =
            rect.Top + 55;


        MouseHelper.Click(
            x,
            y);


        Thread.Sleep(120);

        PressCtrlA();

        Thread.Sleep(50);

        Clipboard.SetText(path);

        PressCtrlV();

        Thread.Sleep(100);

        PressEnter();

        Thread.Sleep(200);
    }

    public static void OpenFileInCsp(
    IntPtr openDialog,
    string filePath)
    {
        string folder =
    Path.GetDirectoryName(filePath)!;

        string file =
            Path.GetFileName(filePath);

        Console.WriteLine(file);

        // 地址栏输入文件夹
        PressCtrlL();

        Thread.Sleep(80);

        Clipboard.SetText(folder);

        PressCtrlV();

        Thread.Sleep(80);

        PressEnter();

        Thread.Sleep(200);


        /// 到文件名输入框


        SetOpenDialogFileName(
    openDialog,
    file);

        Thread.Sleep(80);

        PressTab();

        Thread.Sleep(60);

        PressEnter();
    }
    public static void ConfirmOverwrite()
    {
        Thread.Sleep(100);

        PressEnter();

        Thread.Sleep(150);
    }

    public static void ExportPsdWorkflow(
    Process sai,
    string psdCachePath)
    {


        Wait(100);

        ExportPsd();

        Wait(200);

        IntPtr dialog =
            FindSaveDialog(sai);

        if (dialog == IntPtr.Zero)
            return;

        SetPath(
            dialog,
            psdCachePath);

        Wait(500);

        PressEnter();

        Wait(500);

        PressEnter();

        Wait(500);

        PressEnter();
    }


    public static void SetOpenDialogFileName(
    IntPtr hwnd,
    string fileName)
    {
        AutomationElement root =
            AutomationElement.FromHandle(hwnd);

        var edit =
    root.FindFirst(
        TreeScope.Descendants,
        new AndCondition(
            new PropertyCondition(
                AutomationElement.AutomationIdProperty,
                "1148"),
            new PropertyCondition(
                AutomationElement.ControlTypeProperty,
                ControlType.Edit)));

        if (edit == null)
        {
            return;
        }

        if (edit.TryGetCurrentPattern(
    ValuePattern.Pattern,
    out object pattern))
        {
            ((ValuePattern)pattern).SetValue(fileName);
        }
    }

    public static void ClickOpenButton(IntPtr hwnd)
    {
        AutomationElement root =
            AutomationElement.FromHandle(hwnd);

        var btn =
            root.FindFirst(
                TreeScope.Descendants,
                new PropertyCondition(
                    AutomationElement.NameProperty,
                    "打开"));

        if (btn == null)
        {
            MessageBox.Show("没找到打开按钮");
            return;
        }

        if (btn.TryGetCurrentPattern(
            InvokePattern.Pattern,
            out object p))
        {
            ((InvokePattern)p).Invoke();
        }
    }

    public static void SetOpenFileName(
    IntPtr hwnd,
    string fileName)
    {
        AutomationElement root =
            AutomationElement.FromHandle(hwnd);

        var edit =
            root.FindFirst(
                TreeScope.Descendants,
                new PropertyCondition(
                    AutomationElement.AutomationIdProperty,
                    "1148"));

        if (edit == null)
            return;

        if (edit.TryGetCurrentPattern(
            ValuePattern.Pattern,
            out object pattern))
        {
            ((ValuePattern)pattern)
                .SetValue(fileName);
        }
    }

    public static void ClickFileList(IntPtr dialog)
    {
        var rect =
            MouseHelper.GetRect(dialog);

        // 文件列表区域左上角
        int x = rect.Left + 420;
        int y = rect.Top + 160;

        MouseHelper.Click(x, y);

        Thread.Sleep(100);
    }

    public static void TestClick(IntPtr dialog)
    {
        var rect = MouseHelper.GetRect(dialog);

        MessageBox.Show(
            $"Left={rect.Left}\nTop={rect.Top}\nRight={rect.Right}\nBottom={rect.Bottom}");

        MouseHelper.Click(
            rect.Left + 420,
            rect.Top + 180);
    }

    public static void OpenNewestPsd(IntPtr dialog)
    {
        var rect =
            MouseHelper.GetRect(dialog);


        // 文件缩略图区域
        // 第一个缩略图中心
        int startX = rect.Left + 500;
        int startY = rect.Top + 230;


        // 每个缩略图间隔
        int gapX = 120;


        for (int i = 0; i < 8; i++)
        {
            int x =
                startX + i * gapX;


            MouseHelper.DoubleClick(
                x,
                startY);


            Thread.Sleep(1500);


            break;
        }
    }

    private static int GetPsdIndex(
    IntPtr dialog,
    string psdPath)
    {
        string file =
            Path.GetFileName(psdPath);


        string[] files =
        {
        "12132123.psd",
        "121321412321.psd",
        "sans.psd",
        "新建画布1.psd",
        "新建画布2.psd",
        "新建画布3.psd"
    };


        for (int i = 0; i < files.Length; i++)
        {
            if (files[i] == file)
            {
                return i;
            }
        }


        return -1;
    }

    //==================================================
    // Explorer
    //==================================================

    public static void OpenExplorerSelect(
        string filePath)
    {
        if (!File.Exists(filePath))
            return;

        Process.Start(
            "explorer.exe",
            $"/select,\"{filePath}\"");
    }

    public static System.Windows.Rect GetSelectedExplorerItemRect(
    IntPtr explorer)
    {
        AutomationElement root =
            AutomationElement.FromHandle(explorer);

        AutomationElementCollection items =
     root.FindAll(
         TreeScope.Descendants,
         System.Windows.Automation.Condition.TrueCondition);

        foreach (AutomationElement item in items)
        {
            try
            {
                if (item.Current.ControlType != ControlType.ListItem)
                    continue;

                if (item.TryGetCurrentPattern(
                    SelectionItemPattern.Pattern,
                    out object pattern))
                {
                    SelectionItemPattern p =
                        (SelectionItemPattern)pattern;

                    if (p.Current.IsSelected)
                    {
                        return item.Current.BoundingRectangle;
                    }
                }
            }
            catch
            {
            }
        }

        return System.Windows.Rect.Empty;

    }

    public static void DragSelectedFileToSai(
     Process sai)
    {
        Wait(500);

        IntPtr explorer =
            FindForegroundWindow();


        if (explorer == IntPtr.Zero)
        {
            MessageBox.Show("没有找到 Explorer");
            return;
        }

        var explorerRect =
            MouseHelper.GetRect(explorer);

        var saiRect =
            MouseHelper.GetRect(
                sai.MainWindowHandle);


        System.Windows.Rect rect = System.Windows.Rect.Empty;

        // 最多等待2秒
        for (int i = 0; i < 20; i++)
        {
            rect = GetSelectedExplorerItemRect(explorer);

            if (rect != System.Windows.Rect.Empty)
                break;

            Thread.Sleep(100);
        }

        if (rect == System.Windows.Rect.Empty)
        {

            return;
        }

        int startX =
            (int)(rect.Left + rect.Width / 2);

        int startY =
            (int)(rect.Top + rect.Height / 2);

        int endX =
            saiRect.Left + 700;

        int endY =
            saiRect.Top + 500;

        MouseHelper.Move(startX, startY);

        Thread.Sleep(30);

        MouseHelper.LeftDown();

        Thread.Sleep(50);

        // 拖一半
        MouseHelper.Move(
            endX,
            endY - 100);

        Thread.Sleep(20);

        // ★这里激活SAI★
        Activate(sai);

        Thread.Sleep(80);

        // 再移动一点
        MouseHelper.Move(
            endX,
            endY);

        Thread.Sleep(20);

        MouseHelper.LeftUp();

        Wait(100);

        PressEnter();
    }



}